#!/usr/bin/env python3
"""
Advanced Multiplexer Network Optimization
Implements graph-based algorithms to minimize multiplexer stages
Based on interconnect optimization techniques from Data Path Synthesis
"""

import os
import re
from collections import defaultdict, deque
from typing import Dict, List, Set, Tuple, Optional
import json

class MuxGraph:
    """Directed graph representation of multiplexer network"""
    def __init__(self):
        self.nodes: Dict[str, dict] = {}
        self.edges: List[Tuple[str, str, str]] = []  # (from, to, signal)
        self.mux_nodes: Set[str] = set()
        self.sources: Set[str] = set()
        self.sinks: Set[str] = set()
        self.adjacency: Dict[str, List[str]] = defaultdict(list)
        self.reverse_adjacency: Dict[str, List[str]] = defaultdict(list)
    
    def add_node(self, name: str, node_type: str, **attrs):
        """Add a node to the graph"""
        self.nodes[name] = {
            'type': node_type,
            'name': name,
            **attrs
        }
        if node_type == 'mux':
            self.mux_nodes.add(name)
        elif node_type == 'source':
            self.sources.add(name)
        elif node_type == 'sink':
            self.sinks.add(name)
    
    def add_edge(self, from_node: str, to_node: str, signal: str = ''):
        """Add an edge to the graph"""
        self.edges.append((from_node, to_node, signal))
        self.adjacency[from_node].append(to_node)
        self.reverse_adjacency[to_node].append(from_node)
    
    def get_paths(self, source: str, sink: str) -> List[List[str]]:
        """Find all paths from source to sink"""
        paths = []
        
        def dfs(current: str, path: List[str], visited: Set[str]):
            if current == sink:
                paths.append(path + [current])
                return
            
            visited.add(current)
            for neighbor in self.adjacency.get(current, []):
                if neighbor not in visited:
                    dfs(neighbor, path + [current], visited.copy())
            visited.remove(current)
        
        if source in self.nodes and sink in self.nodes:
            dfs(source, [], set())
        return paths

class AdvancedMuxOptimizer:
    """Advanced multiplexer network optimizer"""
    
    def __init__(self):
        self.graph = MuxGraph()
        self.optimizations_applied = []
        
    def parse_verilog(self, filename: str):
        """Parse Verilog to build graph"""
        with open(filename, 'r') as f:
            content = f.read()
        
        # Extract all mux instantiations
        self._parse_mux_instantiations(content)
        
        # Build graph connections
        self._build_graph_connections(content)
    
    def _parse_mux_instantiations(self, content: str):
        """Parse multiplexer instantiations from Verilog"""
        lines = content.split('\n')
        i = 0
        
        while i < len(lines):
            line = lines[i].strip()
            
            # Match mux instantiations
            mux_match = re.search(
                r'(ALU_Mux|PC_Mux|Result_Mux|Forward_Mux_[AB]|Mux_\d+_to_\d+)\s+(\w+)\s*\(',
                line
            )
            
            if mux_match:
                module_type = mux_match.group(1)
                instance_name = mux_match.group(2)
                
                # Collect full instantiation
                inst_lines = [line]
                paren_count = line.count('(') - line.count(')')
                j = i + 1
                while paren_count > 0 and j < len(lines):
                    inst_lines.append(lines[j])
                    paren_count += lines[j].count('(') - lines[j].count(')')
                    j += 1
                
                inst_block = '\n'.join(inst_lines)
                
                # Extract connections
                connections = {}
                for conn_match in re.finditer(r'\.(\w+)\s*\(([^)]+)\)', inst_block):
                    port = conn_match.group(1)
                    signal = conn_match.group(2).strip()
                    connections[port] = signal
                
                # Determine mux configuration
                inputs = []
                select = None
                output = None
                
                if 'ALU_Mux' in module_type:
                    inputs = [connections.get('WD', ''), connections.get('ImmExt', '')]
                    select = connections.get('ALUSrc', '')
                    output = connections.get('B', '')
                elif 'PC_Mux' in module_type:
                    inputs = [connections.get('PC_Plus_4', ''), connections.get('PC_Target', '')]
                    select = connections.get('PCSrc', '')
                    output = connections.get('PC_Next', '')
                elif 'Result_Mux' in module_type:
                    inputs = [
                        connections.get('ALUResult', ''),
                        connections.get('ReadData', ''),
                        connections.get('PC_Plus_4', '')
                    ]
                    select = connections.get('ResultSrc', '')
                    output = connections.get('Result', '')
                elif 'Forward_Mux_A' in module_type:
                    inputs = [
                        connections.get('RD1E', ''),
                        connections.get('ResultW', ''),
                        connections.get('ALUResultM', '')
                    ]
                    select = connections.get('ForwardAE', '')
                    output = connections.get('SrcAE', '')
                elif 'Forward_Mux_B' in module_type:
                    inputs = [
                        connections.get('RD2E', ''),
                        connections.get('ResultW', ''),
                        connections.get('ALUResultM', '')
                    ]
                    select = connections.get('ForwardBE', '')
                    output = connections.get('SrcBE', '')
                
                if output:
                    # Add mux node
                    self.graph.add_node(
                        instance_name,
                        'mux',
                        inputs=inputs,
                        output=output,
                        select=select,
                        mux_type=module_type
                    )
                    
                    # Add input nodes (sources)
                    for inp in inputs:
                        if inp:
                            if inp not in self.graph.nodes:
                                self.graph.add_node(inp, 'source')
                            self.graph.add_edge(inp, instance_name, inp)
                    
                    # Add output node (sink)
                    if output not in self.graph.nodes:
                        self.graph.add_node(output, 'sink')
                    self.graph.add_edge(instance_name, output, output)
                
                i = j - 1
            i += 1
    
    def _build_graph_connections(self, content: str):
        """Build additional graph connections from assignments"""
        # Find assignments that connect nodes
        for match in re.finditer(r'assign\s+(\w+)\s*=\s*([^;]+);', content):
            lhs = match.group(1)
            rhs = match.group(2).strip()
            
            # Extract operands
            operands = re.findall(r'\b\w+\b', rhs)
            for op in operands:
                if op not in ['assign', 'wire', 'reg', 'and', 'or', 'not']:
                    if op in self.graph.nodes or lhs in self.graph.nodes:
                        if op not in self.graph.nodes:
                            self.graph.add_node(op, 'wire')
                        if lhs not in self.graph.nodes:
                            self.graph.add_node(lhs, 'wire')
                        self.graph.add_edge(op, lhs, op)
    
    def minimize_mux_stages(self):
        """Minimize multiplexer stages using graph algorithms"""
        print("\nApplying graph optimization algorithms...")
        
        # Algorithm 1: Identify serial mux chains
        chains = self._find_serial_mux_chains()
        if chains:
            print(f"  Found {len(chains)} serial mux chains")
            self._optimize_serial_chains(chains)
        
        # Algorithm 2: Merge parallel muxes
        parallel = self._find_parallel_muxes()
        if parallel:
            print(f"  Found {len(parallel)} parallel mux groups")
            self._merge_parallel_muxes(parallel)
        
        # Algorithm 3: Reorder mux stages
        self._reorder_mux_stages()
        
        # Algorithm 4: Eliminate redundant muxes
        redundant = self._find_redundant_muxes()
        if redundant:
            print(f"  Found {len(redundant)} redundant muxes")
            self._eliminate_redundant_muxes(redundant)
    
    def _find_serial_mux_chains(self) -> List[List[str]]:
        """Find chains of muxes connected in series"""
        chains = []
        visited = set()
        
        for mux in self.graph.mux_nodes:
            if mux in visited:
                continue
            
            chain = [mux]
            visited.add(mux)
            current = mux
            
            # Follow forward
            while True:
                neighbors = self.graph.adjacency.get(current, [])
                next_mux = None
                for neighbor in neighbors:
                    if neighbor in self.graph.mux_nodes and neighbor not in visited:
                        next_mux = neighbor
                        break
                
                if next_mux:
                    chain.append(next_mux)
                    visited.add(next_mux)
                    current = next_mux
                else:
                    break
            
            if len(chain) > 1:
                chains.append(chain)
        
        return chains
    
    def _optimize_serial_chains(self, chains: List[List[str]]):
        """Optimize serial mux chains by combining them"""
        optimized = 0
        for chain in chains:
            if len(chain) >= 2:
                # Can combine into single mux with more inputs
                print(f"    Chain: {' -> '.join(chain)}")
                # Mark for optimization
                for mux in chain:
                    if mux in self.graph.nodes:
                        self.graph.nodes[mux]['optimized'] = True
                optimized += 1
                self.optimizations_applied.append({
                    'type': 'serial_chain_merge',
                    'chain': chain,
                    'savings': len(chain) - 1
                })
        print(f"    Optimized {optimized} chains")
    
    def _find_parallel_muxes(self) -> List[List[str]]:
        """Find muxes with same inputs (can be merged)"""
        mux_groups = defaultdict(list)
        
        for mux in self.graph.mux_nodes:
            if mux in self.graph.nodes:
                inputs = tuple(sorted(self.graph.nodes[mux].get('inputs', [])))
                mux_groups[inputs].append(mux)
        
        # Return groups with multiple muxes
        return [mux_list for mux_list in mux_groups.values() if len(mux_list) > 1]
    
    def _merge_parallel_muxes(self, parallel_groups: List[List[str]]):
        """Merge parallel muxes with same inputs"""
        merged = 0
        for group in parallel_groups:
            if len(group) > 1:
                print(f"    Parallel group: {', '.join(group)}")
                # Mark for merging
                for mux in group:
                    if mux in self.graph.nodes:
                        self.graph.nodes[mux]['optimized'] = True
                merged += len(group) - 1
                self.optimizations_applied.append({
                    'type': 'parallel_merge',
                    'group': group,
                    'savings': len(group) - 1
                })
        print(f"    Potential merges: {merged} muxes")
    
    def _reorder_mux_stages(self):
        """Reorder mux stages to minimize depth"""
        # Calculate depths
        depths = {}
        queue = deque()
        
        # Initialize sources
        for source in self.graph.sources:
            depths[source] = 0
            queue.append(source)
        
        # BFS to calculate depths
        while queue:
            node = queue.popleft()
            for neighbor in self.graph.adjacency.get(node, []):
                if neighbor not in depths:
                    depths[neighbor] = depths[node] + 1
                    queue.append(neighbor)
                elif depths[neighbor] < depths[node] + 1:
                    depths[neighbor] = depths[node] + 1
        
        # Update mux depths
        for mux in self.graph.mux_nodes:
            if mux in depths:
                if mux in self.graph.nodes:
                    self.graph.nodes[mux]['depth'] = depths[mux]
    
    def _find_redundant_muxes(self) -> List[str]:
        """Find redundant muxes (e.g., mux with same input on all paths)"""
        redundant = []
        
        for mux in self.graph.mux_nodes:
            if mux in self.graph.nodes:
                inputs = self.graph.nodes[mux].get('inputs', [])
                # Check if all inputs are the same
                if len(inputs) > 1 and len(set(inputs)) == 1:
                    redundant.append(mux)
        
        return redundant
    
    def _eliminate_redundant_muxes(self, redundant: List[str]):
        """Eliminate redundant muxes"""
        for mux in redundant:
            if mux in self.graph.nodes:
                inputs = self.graph.nodes[mux].get('inputs', [])
                if inputs:
                    # Replace mux with direct connection
                    output = self.graph.nodes[mux].get('output', '')
                    print(f"    Eliminating redundant mux: {mux} (all inputs = {inputs[0]})")
                    self.graph.nodes[mux]['eliminated'] = True
                    self.optimizations_applied.append({
                        'type': 'redundant_elimination',
                        'mux': mux,
                        'replacement': inputs[0]
                    })
    
    def generate_optimized_netlist(self, output_file: str):
        """Generate optimized netlist with recommendations"""
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        with open(output_file, 'w') as f:
            f.write("// ============================================================================\n")
            f.write("// Advanced Optimized Multiplexer Network\n")
            f.write("// Generated using graph-based optimization algorithms\n")
            f.write("// ============================================================================\n\n")
            f.write("`timescale 1ns / 1ps\n\n")
            
            # Statistics
            f.write("// Optimization Statistics:\n")
            f.write(f"//   Total Muxes: {len(self.graph.mux_nodes)}\n")
            f.write(f"//   Optimizations Applied: {len(self.optimizations_applied)}\n")
            f.write(f"//   Total Nodes: {len(self.graph.nodes)}\n")
            f.write(f"//   Total Edges: {len(self.graph.edges)}\n\n")
            
            # Optimization details
            f.write("// Optimizations Applied:\n")
            for opt in self.optimizations_applied:
                f.write(f"//   {opt['type']}: {opt.get('savings', 0)} mux(es) saved\n")
            f.write("\n")
            
            # Mux network
            f.write("// Multiplexer Network:\n")
            for mux in sorted(self.graph.mux_nodes):
                if mux in self.graph.nodes:
                    node = self.graph.nodes[mux]
                    f.write(f"//   {mux}:\n")
                    f.write(f"//     Inputs: {', '.join(node.get('inputs', []))}\n")
                    f.write(f"//     Output: {node.get('output', '')}\n")
                    f.write(f"//     Select: {node.get('select', '')}\n")
                    if node.get('optimized'):
                        f.write(f"//     [OPTIMIZED]\n")
                    if node.get('eliminated'):
                        f.write(f"//     [ELIMINATED - replace with {node.get('inputs', [''])[0]}]\n")
                    f.write("\n")
        
        print(f"  Optimized netlist: {output_file}")

def main():
    optimizer = AdvancedMuxOptimizer()
    
    print("=" * 80)
    print("Advanced Multiplexer Network Optimization")
    print("Graph-Based Algorithms for Minimizing Mux Stages")
    print("=" * 80)
    print()
    
    # Parse Verilog
    datapath_file = 'rtl/Pipelined_Datapath.v'
    if os.path.exists(datapath_file):
        print(f"Parsing {datapath_file}...")
        optimizer.parse_verilog(datapath_file)
        print(f"  Found {len(optimizer.graph.mux_nodes)} multiplexers")
        print(f"  Found {len(optimizer.graph.sources)} sources")
        print(f"  Found {len(optimizer.graph.sinks)} sinks")
    else:
        print(f"Error: {datapath_file} not found!")
        return
    
    # Optimize
    optimizer.minimize_mux_stages()
    
    # Generate output
    optimizer.generate_optimized_netlist('netlist/advanced_optimized_mux.v')
    
    print("\n" + "=" * 80)
    print("Optimization Complete!")
    print("=" * 80)

if __name__ == '__main__':
    main()

