#!/usr/bin/env python3
"""
Multiplexer Network Graph Optimization
Implements algorithms to minimize multiplexer stages
Based on: Data Path Synthesis - Interconnect Optimization (ayan.pdf)
Techniques: Transfer Graph, Conflict Graph, Register-Interconnect Optimization
"""

import os
import re
from collections import defaultdict, deque
from typing import Dict, List, Set, Tuple, Optional
import json

class TransferGraph:
    """
    Transfer Graph: Directed graph representing data transfers
    Nodes: Data sources and sinks
    Edges: Data transfers through muxes
    """
    def __init__(self):
        self.nodes: Dict[str, dict] = {}
        self.edges: List[Tuple[str, str, dict]] = []  # (from, to, attributes)
        self.mux_nodes: Set[str] = set()
        self.sources: Set[str] = set()
        self.sinks: Set[str] = set()
        self.adjacency: Dict[str, List[Tuple[str, dict]]] = defaultdict(list)
        
    def add_node(self, name: str, node_type: str, **attrs):
        """Add a node to the transfer graph"""
        self.nodes[name] = {'type': node_type, 'name': name, **attrs}
        if node_type == 'mux':
            self.mux_nodes.add(name)
        elif node_type == 'source':
            self.sources.add(name)
        elif node_type == 'sink':
            self.sinks.add(name)
    
    def add_edge(self, from_node: str, to_node: str, edge_data: dict = None, **attrs):
        """Add an edge representing a data transfer"""
        if edge_data is None:
            edge_data = attrs
        else:
            edge_data.update(attrs)
        self.edges.append((from_node, to_node, edge_data))
        self.adjacency[from_node].append((to_node, edge_data))
    
    def find_paths(self, source: str, sink: str, max_depth: int = 10) -> List[List[str]]:
        """Find all paths from source to sink"""
        paths = []
        
        def dfs(current: str, path: List[str], visited: Set[str], depth: int):
            if depth > max_depth:
                return
            if current == sink:
                paths.append(path + [current])
                return
            
            visited.add(current)
            for neighbor, _ in self.adjacency.get(current, []):
                if neighbor not in visited:
                    dfs(neighbor, path + [current], visited.copy(), depth + 1)
            visited.remove(current)
        
        if source in self.nodes and sink in self.nodes:
            dfs(source, [], set(), 0)
        return paths

class ConflictGraph:
    """
    Conflict Graph: Undirected graph showing muxes that cannot share resources
    """
    def __init__(self):
        self.nodes: Set[str] = set()
        self.edges: Set[Tuple[str, str]] = set()
    
    def add_conflict(self, mux1: str, mux2: str):
        """Add a conflict between two muxes"""
        self.nodes.add(mux1)
        self.nodes.add(mux2)
        if mux1 < mux2:
            self.edges.add((mux1, mux2))
        else:
            self.edges.add((mux2, mux1))
    
    def can_merge(self, mux1: str, mux2: str) -> bool:
        """Check if two muxes can be merged (no conflict)"""
        return (mux1, mux2) not in self.edges and (mux2, mux1) not in self.edges

class MuxNetworkOptimizer:
    """
    Main optimizer implementing graph-based algorithms
    """
    def __init__(self):
        self.transfer_graph = TransferGraph()
        self.conflict_graph = ConflictGraph()
        self.optimizations = []
        self.mux_info: Dict[str, dict] = {}
        
    def parse_verilog(self, filename: str):
        """Parse Verilog to build transfer graph"""
        with open(filename, 'r') as f:
            content = f.read()
        
        print(f"Parsing {filename}...")
        self._extract_muxes(content)
        self._build_transfer_graph(content)
        print(f"  Extracted {len(self.transfer_graph.mux_nodes)} multiplexers")
    
    def _extract_muxes(self, content: str):
        """Extract all multiplexer instantiations"""
        lines = content.split('\n')
        i = 0
        
        while i < len(lines):
            line = lines[i].strip()
            
            # Match mux patterns
            mux_match = re.search(
                r'(ALU_Mux|PC_Mux|Result_Mux|Forward_Mux_[AB])\s+(\w+)\s*\(',
                line
            )
            
            if mux_match:
                module_type = mux_match.group(1)
                instance_name = mux_match.group(2)
                
                # Collect full instantiation
                inst_lines = [line]
                paren_count = line.count('(') - line.count(')')
                j = i + 1
                while paren_count > 0 and j < len(lines):
                    inst_lines.append(lines[j])
                    paren_count += lines[j].count('(') - lines[j].count(')')
                    j += 1
                
                inst_block = '\n'.join(inst_lines)
                
                # Extract connections
                connections = {}
                for conn_match in re.finditer(r'\.(\w+)\s*\(([^)]+)\)', inst_block):
                    port = conn_match.group(1)
                    signal = conn_match.group(2).strip()
                    connections[port] = signal
                
                # Determine mux configuration
                inputs = []
                select = None
                output = None
                mux_type = '2:1'
                
                if 'ALU_Mux' in module_type:
                    inputs = [connections.get('WD', ''), connections.get('ImmExt', '')]
                    select = connections.get('ALUSrc', '')
                    output = connections.get('B', '')
                    mux_type = '2:1'
                elif 'PC_Mux' in module_type:
                    inputs = [connections.get('PC_Plus_4', ''), connections.get('PC_Target', '')]
                    select = connections.get('PCSrc', '')
                    output = connections.get('PC_Next', '')
                    mux_type = '2:1'
                elif 'Result_Mux' in module_type:
                    inputs = [
                        connections.get('ALUResult', ''),
                        connections.get('ReadData', ''),
                        connections.get('PC_Plus_4', '')
                    ]
                    select = connections.get('ResultSrc', '')
                    output = connections.get('Result', '')
                    mux_type = '3:1'
                elif 'Forward_Mux_A' in module_type:
                    inputs = [
                        connections.get('RD1E', ''),
                        connections.get('ResultW', ''),
                        connections.get('ALUResultM', '')
                    ]
                    select = connections.get('ForwardAE', '')
                    output = connections.get('SrcAE', '')
                    mux_type = '3:1'
                elif 'Forward_Mux_B' in module_type:
                    inputs = [
                        connections.get('RD2E', ''),
                        connections.get('ResultW', ''),
                        connections.get('ALUResultM', '')
                    ]
                    select = connections.get('ForwardBE', '')
                    output = connections.get('SrcBE', '')
                    mux_type = '3:1'
                
                if output:
                    # Store mux information
                    self.mux_info[instance_name] = {
                        'type': mux_type,
                        'inputs': [inp for inp in inputs if inp],
                        'output': output,
                        'select': select,
                        'module_type': module_type
                    }
                    
                    # Add to transfer graph
                    self.transfer_graph.add_node(
                        instance_name,
                        'mux',
                        inputs=inputs,
                        output=output,
                        select=select,
                        mux_type=mux_type
                    )
                    
                    # Add input sources
                    for inp in inputs:
                        if inp:
                            if inp not in self.transfer_graph.nodes:
                                self.transfer_graph.add_node(inp, 'source')
                            self.transfer_graph.add_edge(inp, instance_name, {'signal': inp})
                    
                    # Add output sink
                    if output not in self.transfer_graph.nodes:
                        self.transfer_graph.add_node(output, 'sink')
                    self.transfer_graph.add_edge(instance_name, output, {'signal': output})
                
                i = j - 1
            i += 1
    
    def _build_transfer_graph(self, content: str):
        """Build complete transfer graph from assignments"""
        # Find assignments that create additional connections
        for match in re.finditer(r'assign\s+(\w+)\s*=\s*([^;]+);', content):
            lhs = match.group(1)
            rhs = match.group(2).strip()
            
            # Extract operands
            operands = re.findall(r'\b\w+\b', rhs)
            for op in operands:
                if op not in ['assign', 'wire', 'reg', 'and', 'or', 'not']:
                    if op in self.transfer_graph.nodes or lhs in self.transfer_graph.nodes:
                        if op not in self.transfer_graph.nodes:
                            self.transfer_graph.add_node(op, 'wire')
                        if lhs not in self.transfer_graph.nodes:
                            self.transfer_graph.add_node(lhs, 'wire')
                        self.transfer_graph.add_edge(op, lhs, {'type': 'assignment'})
    
    def optimize(self):
        """Apply optimization algorithms"""
        print("\nApplying optimization algorithms...")
        
        # Algorithm 1: Serial Chain Optimization
        self._optimize_serial_chains()
        
        # Algorithm 2: Parallel Mux Merging
        self._merge_parallel_muxes()
        
        # Algorithm 3: Stage Reduction
        self._reduce_mux_stages()
        
        # Algorithm 4: Critical Path Optimization
        self._optimize_critical_paths()
        
        # Algorithm 5: Redundant Mux Elimination
        self._eliminate_redundant_muxes()
    
    def _optimize_serial_chains(self):
        """Optimize serial mux chains (mux -> mux)"""
        print("  [1] Optimizing serial mux chains...")
        
        chains = []
        visited = set()
        
        # Find chains: mux -> mux connections
        for mux in self.transfer_graph.mux_nodes:
            if mux in visited:
                continue
            
            chain = [mux]
            visited.add(mux)
            current = mux
            
            # Follow chain forward
            while True:
                next_mux = None
                for neighbor, edge_data in self.transfer_graph.adjacency.get(current, []):
                    if neighbor in self.transfer_graph.mux_nodes and neighbor not in visited:
                        next_mux = neighbor
                        break
                
                if next_mux:
                    chain.append(next_mux)
                    visited.add(next_mux)
                    current = next_mux
                else:
                    break
            
            if len(chain) > 1:
                chains.append(chain)
        
        if chains:
            print(f"    Found {len(chains)} serial chains")
            for chain in chains:
                print(f"      Chain: {' -> '.join(chain)}")
                # Optimization: Can combine into single mux
                savings = len(chain) - 1
                self.optimizations.append({
                    'type': 'serial_chain_merge',
                    'chain': chain,
                    'savings': savings,
                    'description': f"Merge {len(chain)} muxes into 1, saving {savings} mux stages"
                })
        else:
            print("    No serial chains found")
    
    def _merge_parallel_muxes(self):
        """Merge parallel muxes with same inputs"""
        print("  [2] Merging parallel muxes...")
        
        # Group muxes by input signature
        mux_groups = defaultdict(list)
        for mux_name, mux_data in self.mux_info.items():
            inputs = tuple(sorted(mux_data['inputs']))
            mux_groups[inputs].append(mux_name)
        
        # Find groups with multiple muxes
        mergeable = [(sig, mux_list) for sig, mux_list in mux_groups.items() if len(mux_list) > 1]
        
        if mergeable:
            total_savings = 0
            for sig, mux_list in mergeable:
                print(f"    Found {len(mux_list)} muxes with same inputs")
                print(f"      Inputs: {', '.join(sig[:3])}")
                print(f"      Muxes: {', '.join(mux_list)}")
                
                # Check conflicts
                can_merge = True
                for i in range(len(mux_list)):
                    for j in range(i+1, len(mux_list)):
                        if not self.conflict_graph.can_merge(mux_list[i], mux_list[j]):
                            can_merge = False
                            self.conflict_graph.add_conflict(mux_list[i], mux_list[j])
                
                if can_merge:
                    savings = len(mux_list) - 1
                    total_savings += savings
                    self.optimizations.append({
                        'type': 'parallel_merge',
                        'group': mux_list,
                        'savings': savings,
                        'description': f"Merge {len(mux_list)} parallel muxes, saving {savings} muxes"
                    })
            
            if total_savings > 0:
                print(f"    Total potential savings: {total_savings} muxes")
            else:
                print("    Muxes have conflicts, cannot merge")
        else:
            print("    No mergeable parallel muxes found")
    
    def _reduce_mux_stages(self):
        """Reduce number of mux stages in paths"""
        print("  [3] Reducing mux stages...")
        
        # Find all source-to-sink paths
        all_paths = []
        for source in list(self.transfer_graph.sources)[:10]:  # Limit for performance
            for sink in self.transfer_graph.sinks:
                paths = self.transfer_graph.find_paths(source, sink, max_depth=10)
                all_paths.extend(paths)
        
        # Find paths with multiple mux stages
        multi_mux_paths = []
        for path in all_paths:
            mux_count = sum(1 for node in path if node in self.transfer_graph.mux_nodes)
            if mux_count > 1:
                multi_mux_paths.append((path, mux_count))
        
        if multi_mux_paths:
            # Sort by mux count
            multi_mux_paths.sort(key=lambda x: x[1], reverse=True)
            
            print(f"    Found {len(multi_mux_paths)} paths with multiple mux stages")
            for path, mux_count in multi_mux_paths[:5]:
                path_str = ' -> '.join(path[-5:])
                print(f"      Path: {path_str} ({mux_count} muxes)")
                
                # Optimization: Combine muxes in path
                muxes_in_path = [node for node in path if node in self.transfer_graph.mux_nodes]
                if len(muxes_in_path) > 1:
                    self.optimizations.append({
                        'type': 'stage_reduction',
                        'path': path,
                        'muxes': muxes_in_path,
                        'savings': len(muxes_in_path) - 1,
                        'description': f"Reduce {len(muxes_in_path)} mux stages to 1 in path"
                    })
        else:
            print("    All paths have acceptable mux stage count")
    
    def _optimize_critical_paths(self):
        """Optimize critical paths (longest paths)"""
        print("  [4] Optimizing critical paths...")
        
        # Find longest paths
        all_paths = []
        for source in list(self.transfer_graph.sources)[:10]:
            for sink in self.transfer_graph.sinks:
                paths = self.transfer_graph.find_paths(source, sink, max_depth=10)
                all_paths.extend(paths)
        
        if all_paths:
            # Sort by length
            all_paths.sort(key=len, reverse=True)
            critical_paths = all_paths[:5]
            
            print(f"    Found {len(critical_paths)} critical paths")
            for i, path in enumerate(critical_paths, 1):
                mux_count = sum(1 for node in path if node in self.transfer_graph.mux_nodes)
                path_str = ' -> '.join(path[-4:])
                print(f"      Path {i}: {len(path)} nodes, {mux_count} muxes")
                print(f"        {path_str}")
                
                # Mark for optimization
                muxes_in_path = [node for node in path if node in self.transfer_graph.mux_nodes]
                if muxes_in_path:
                    self.optimizations.append({
                        'type': 'critical_path_optimization',
                        'path': path,
                        'muxes': muxes_in_path,
                        'description': f"Optimize critical path with {len(muxes_in_path)} muxes"
                    })
        else:
            print("    No critical paths found")
    
    def _eliminate_redundant_muxes(self):
        """Eliminate redundant muxes"""
        print("  [5] Eliminating redundant muxes...")
        
        redundant = []
        for mux_name, mux_data in self.mux_info.items():
            inputs = mux_data['inputs']
            # Check if all inputs are the same
            if len(inputs) > 1 and len(set(inputs)) == 1:
                redundant.append(mux_name)
            # Check if mux has only one valid input path
            elif len(set(inputs)) == 1 and inputs[0]:
                redundant.append(mux_name)
        
        if redundant:
            print(f"    Found {len(redundant)} redundant muxes")
            for mux in redundant:
                inputs = self.mux_info[mux]['inputs']
                print(f"      {mux}: All inputs = {inputs[0] if inputs else 'N/A'}")
                self.optimizations.append({
                    'type': 'redundant_elimination',
                    'mux': mux,
                    'replacement': inputs[0] if inputs else '',
                    'description': f"Eliminate {mux}, replace with direct connection"
                })
        else:
            print("    No redundant muxes found")
    
    def generate_optimized_netlist(self, output_file: str):
        """Generate optimized netlist with recommendations"""
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        with open(output_file, 'w') as f:
            f.write("// ============================================================================\n")
            f.write("// Optimized Multiplexer Network Netlist\n")
            f.write("// Generated using Graph-Based Optimization Algorithms\n")
            f.write("// Based on: Data Path Synthesis - Interconnect Optimization\n")
            f.write("// ============================================================================\n\n")
            f.write("`timescale 1ns / 1ps\n\n")
            
            # Summary
            f.write("// ============================================================================\n")
            f.write("// OPTIMIZATION SUMMARY\n")
            f.write("// ============================================================================\n\n")
            f.write(f"// Total Multiplexers: {len(self.transfer_graph.mux_nodes)}\n")
            f.write(f"// Optimizations Applied: {len(self.optimizations)}\n")
            total_savings = sum(opt.get('savings', 0) for opt in self.optimizations)
            f.write(f"// Total Mux Stages Saved: {total_savings}\n")
            f.write(f"// Data Sources: {len(self.transfer_graph.sources)}\n")
            f.write(f"// Data Sinks: {len(self.transfer_graph.sinks)}\n\n")
            
            # Optimization details
            f.write("// ============================================================================\n")
            f.write("// OPTIMIZATIONS APPLIED\n")
            f.write("// ============================================================================\n\n")
            
            for i, opt in enumerate(self.optimizations, 1):
                f.write(f"// Optimization {i}: {opt['type']}\n")
                f.write(f"//   {opt.get('description', 'N/A')}\n")
                if 'savings' in opt:
                    f.write(f"//   Savings: {opt['savings']} mux stage(s)\n")
                f.write("\n")
            
            # Current mux network
            f.write("// ============================================================================\n")
            f.write("// CURRENT MULTIPLEXER NETWORK\n")
            f.write("// ============================================================================\n\n")
            
            for mux_name in sorted(self.transfer_graph.mux_nodes):
                if mux_name in self.mux_info:
                    mux_data = self.mux_info[mux_name]
                    f.write(f"// {mux_name} ({mux_data['type']}):\n")
                    f.write(f"//   Inputs: {', '.join(mux_data['inputs'])}\n")
                    f.write(f"//   Output: {mux_data['output']}\n")
                    f.write(f"//   Select: {mux_data['select']}\n")
                    f.write("\n")
            
            # Optimization recommendations
            f.write("// ============================================================================\n")
            f.write("// OPTIMIZATION RECOMMENDATIONS\n")
            f.write("// ============================================================================\n\n")
            
            if self.optimizations:
                f.write("// Apply the following optimizations to reduce mux stages:\n\n")
                
                # Group by type
                by_type = defaultdict(list)
                for opt in self.optimizations:
                    by_type[opt['type']].append(opt)
                
                for opt_type, opts in by_type.items():
                    f.write(f"// {opt_type.upper().replace('_', ' ')}:\n")
                    for opt in opts:
                        f.write(f"//   - {opt.get('description', 'N/A')}\n")
                    f.write("\n")
            else:
                f.write("// Current mux network is already optimized.\n")
                f.write("// No further optimizations recommended.\n\n")
        
        print(f"  Optimized netlist: {output_file}")
    
    def generate_report(self, output_file: str):
        """Generate detailed optimization report"""
        with open(output_file, 'w') as f:
            f.write("# Multiplexer Network Optimization Report\n\n")
            f.write("## Executive Summary\n\n")
            f.write(f"- **Total Multiplexers**: {len(self.transfer_graph.mux_nodes)}\n")
            f.write(f"- **Optimizations Applied**: {len(self.optimizations)}\n")
            total_savings = sum(opt.get('savings', 0) for opt in self.optimizations)
            f.write(f"- **Total Mux Stages Saved**: {total_savings}\n")
            f.write(f"- **Optimization Potential**: {total_savings / len(self.transfer_graph.mux_nodes) * 100 if self.transfer_graph.mux_nodes else 0:.1f}%\n\n")
            
            f.write("## Multiplexer Network Analysis\n\n")
            f.write("### Current Mux Configuration\n\n")
            for mux_name in sorted(self.transfer_graph.mux_nodes):
                if mux_name in self.mux_info:
                    mux_data = self.mux_info[mux_name]
                    f.write(f"**{mux_name}** ({mux_data['type']}):\n")
                    f.write(f"- Inputs: {', '.join(mux_data['inputs'])}\n")
                    f.write(f"- Output: {mux_data['output']}\n")
                    f.write(f"- Select Signal: {mux_data['select']}\n\n")
            
            f.write("## Optimization Results\n\n")
            for i, opt in enumerate(self.optimizations, 1):
                f.write(f"### Optimization {i}: {opt['type'].replace('_', ' ').title()}\n\n")
                f.write(f"{opt.get('description', 'N/A')}\n\n")
                if 'savings' in opt:
                    f.write(f"**Savings**: {opt['savings']} mux stage(s)\n\n")
            
            f.write("## Implementation Recommendations\n\n")
            f.write("1. **Serial Chain Merging**: Combine consecutive muxes\n")
            f.write("2. **Parallel Mux Sharing**: Share mux logic for common inputs\n")
            f.write("3. **Stage Reduction**: Move muxes to earlier pipeline stages\n")
            f.write("4. **Critical Path Optimization**: Optimize longest paths first\n")
            f.write("5. **Redundant Elimination**: Remove unnecessary muxes\n\n")

def main():
    optimizer = MuxNetworkOptimizer()
    
    print("=" * 80)
    print("Multiplexer Network Graph Optimization")
    print("Minimizing Multiplexer Stages using Graph Algorithms")
    print("Based on: Data Path Synthesis - Interconnect Optimization")
    print("=" * 80)
    print()
    
    # Parse Verilog
    datapath_file = 'rtl/Pipelined_Datapath.v'
    if not os.path.exists(datapath_file):
        print(f"Error: {datapath_file} not found!")
        return
    
    optimizer.parse_verilog(datapath_file)
    
    # Optimize
    optimizer.optimize()
    
    # Generate outputs
    optimizer.generate_optimized_netlist('netlist/optimized_mux_network.v')
    optimizer.generate_report('netlist/optimization_report.md')
    
    print("\n" + "=" * 80)
    print("Optimization Complete!")
    print("=" * 80)
    print("\nOutput files:")
    print("  - netlist/optimized_mux_network.v")
    print("  - netlist/optimization_report.md")
    print(f"\nTotal optimizations: {len(optimizer.optimizations)}")
    total_savings = sum(opt.get('savings', 0) for opt in optimizer.optimizations)
    print(f"Potential mux stage savings: {total_savings}")

if __name__ == '__main__':
    main()
