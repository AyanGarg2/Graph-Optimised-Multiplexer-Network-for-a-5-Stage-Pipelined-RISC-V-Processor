#!/usr/bin/env python3
"""
Multiplexer Network Graph Optimization
Minimizes multiplexer stages using graph algorithms
Based on directed graph representation with data sources and sinks
Reference: Data Path Synthesis - Interconnect Optimization
"""

import os
import re
import glob
from collections import defaultdict, deque
from typing import Dict, List, Set, Tuple, Optional
import json

class MuxNode:
    """Represents a node in the multiplexer network graph"""
    def __init__(self, name: str, node_type: str, width: int = 32):
        self.name = name
        self.type = node_type  # 'source', 'mux', 'sink', 'register', 'alu'
        self.width = width
        self.inputs: List[str] = []
        self.output: Optional[str] = None
        self.select_signal: Optional[str] = None
        self.stage = 0  # Pipeline stage
        self.depth = 0  # Depth in mux tree
        self.optimized = False
        self.mux_type = None  # '2:1', '3:1', '4:1'
        
    def __repr__(self):
        return f"{self.type.upper()}({self.name}, stage={self.stage}, depth={self.depth})"

class MuxGraphOptimizer:
    """Optimizes multiplexer network using graph algorithms"""
    
    def __init__(self):
        self.nodes: Dict[str, MuxNode] = {}
        self.edges: List[Tuple[str, str]] = []  # (from, to)
        self.sources: Set[str] = set()  # Data sources
        self.sinks: Set[str] = set()  # Data sinks
        self.mux_nodes: Set[str] = set()  # Multiplexer nodes
        self.pipeline_stages = {
            'IF': 0, 'ID': 1, 'EX': 2, 'MEM': 3, 'WB': 4
        }
        
    def parse_verilog_file(self, filename: str):
        """Parse Verilog file to extract multiplexer network"""
        with open(filename, 'r') as f:
            content = f.read()
        
        # Extract module instantiations
        self._extract_instantiations(content)
        
        # Extract wire assignments
        self._extract_assignments(content)
        
        # Identify sources and sinks
        self._identify_sources_sinks(content)
    
    def _extract_instantiations(self, content: str):
        """Extract module instantiations, especially muxes"""
        # Pattern to match mux instantiations (handles multiline)
        # Match: ALU_Mux alu_mux( ... ) or Forward_Mux_A fwdA( ... )
        lines = content.split('\n')
        i = 0
        
        while i < len(lines):
            line = lines[i].strip()
            
            # Check for mux instantiation
            mux_match = re.search(r'(ALU_Mux|PC_Mux|Result_Mux|Forward_Mux_[AB]|Mux_\d+_to_\d+)\s+(\w+)\s*\(', line)
            
            if mux_match:
                module_type = mux_match.group(1)
                instance_name = mux_match.group(2)
                
                # Collect full instantiation block
                inst_lines = [line]
                paren_count = line.count('(') - line.count(')')
                j = i + 1
                
                while paren_count > 0 and j < len(lines):
                    inst_lines.append(lines[j])
                    paren_count += lines[j].count('(') - lines[j].count(')')
                    j += 1
                
                inst_block = '\n'.join(inst_lines)
                
                # Extract port connections
                connections = {}
                conn_pattern = r'\.(\w+)\s*\(([^)]+)\)'
                for conn_match in re.finditer(conn_pattern, inst_block):
                    port = conn_match.group(1)
                    signal = conn_match.group(2).strip()
                    connections[port] = signal
                
                # Determine mux configuration based on type
                inputs = []
                select = None
                output = None
                mux_type = '2:1'
                
                if 'ALU_Mux' in module_type:
                    inputs = [connections.get('WD', ''), connections.get('ImmExt', '')]
                    select = connections.get('ALUSrc', '')
                    output = connections.get('B', '')
                    mux_type = '2:1'
                elif 'PC_Mux' in module_type:
                    inputs = [connections.get('PC_Plus_4', ''), connections.get('PC_Target', '')]
                    select = connections.get('PCSrc', '')
                    output = connections.get('PC_Next', '')
                    mux_type = '2:1'
                elif 'Result_Mux' in module_type:
                    inputs = [
                        connections.get('ALUResult', ''),
                        connections.get('ReadData', ''),
                        connections.get('PC_Plus_4', '')
                    ]
                    select = connections.get('ResultSrc', '')
                    output = connections.get('Result', '')
                    mux_type = '3:1'
                elif 'Forward_Mux_A' in module_type:
                    inputs = [
                        connections.get('RD1E', ''),
                        connections.get('ResultW', ''),
                        connections.get('ALUResultM', '')
                    ]
                    select = connections.get('ForwardAE', '')
                    output = connections.get('SrcAE', '')
                    mux_type = '3:1'
                elif 'Forward_Mux_B' in module_type:
                    inputs = [
                        connections.get('RD2E', ''),
                        connections.get('ResultW', ''),
                        connections.get('ALUResultM', '')
                    ]
                    select = connections.get('ForwardBE', '')
                    output = connections.get('SrcBE', '')
                    mux_type = '3:1'
                
                # Create mux node
                if output:
                    node = MuxNode(instance_name, 'mux', width=32)
                    node.inputs = [inp for inp in inputs if inp]
                    node.select_signal = select
                    node.output = output
                    node.mux_type = mux_type
                    
                    # Determine pipeline stage from signal names
                    if 'D' in output or 'D' in str(inputs):
                        node.stage = 1  # ID stage
                    elif 'E' in output or 'E' in str(inputs):
                        node.stage = 2  # EX stage
                    elif 'M' in output or 'M' in str(inputs):
                        node.stage = 3  # MEM stage
                    elif 'W' in output or 'W' in str(inputs):
                        node.stage = 4  # WB stage
                    else:
                        node.stage = 0  # IF stage
                    
                    self.nodes[instance_name] = node
                    self.mux_nodes.add(instance_name)
                    
                    # Add edges: inputs -> mux -> output
                    for inp in node.inputs:
                        if inp:
                            self.edges.append((inp, instance_name))
                            # Create source node if doesn't exist
                            if inp not in self.nodes:
                                src_node = MuxNode(inp, 'source', width=32)
                                self.nodes[inp] = src_node
                                self.sources.add(inp)
                    
                    if output:
                        self.edges.append((instance_name, output))
                        # Create sink node if it's a sink
                        if output not in self.nodes:
                            sink_node = MuxNode(output, 'sink', width=32)
                            self.nodes[output] = sink_node
                            self.sinks.add(output)
                
                i = j - 1
            i += 1
    
    def _extract_assignments(self, content: str):
        """Extract wire assignments"""
        assign_pattern = r'assign\s+(\w+)\s*=\s*([^;]+);'
        for match in re.finditer(assign_pattern, content):
            lhs = match.group(1)
            rhs = match.group(2).strip()
            
            # Create or update node
            if lhs not in self.nodes:
                node = MuxNode(lhs, 'wire', width=32)
                self.nodes[lhs] = node
            else:
                node = self.nodes[lhs]
            
            # Parse RHS for connections
            operands = re.findall(r'\b\w+\b', rhs)
            for op in operands:
                if op not in ['assign', 'wire', 'reg', 'and', 'or', 'not']:
                    self.edges.append((op, lhs))
    
    def _identify_sources_sinks(self, content: str):
        """Identify data sources and sinks"""
        # Sources: Register file outputs, immediate values, constants
        source_keywords = ['RD1', 'RD2', 'ImmExt', 'PC', 'PCPlus4']
        for keyword in source_keywords:
            pattern = rf'\b{keyword}\w*\b'
            matches = re.findall(pattern, content)
            for match in matches:
                if match not in ['PC_Mux', 'PC_Plus_4', 'PC_Target']:
                    self.sources.add(match)
        
        # Sinks: ALU inputs, memory addresses, register file inputs
        sink_keywords = ['SrcA', 'SrcB', 'WD3', 'ResultW', 'DataAddr']
        for keyword in sink_keywords:
            pattern = rf'\b{keyword}\w*\b'
            matches = re.findall(pattern, content)
            for match in matches:
                self.sinks.add(match)
    
    def build_graph(self):
        """Build directed graph representation"""
        print("Building multiplexer network graph...")
        print(f"  Nodes: {len(self.nodes)}")
        print(f"  Edges: {len(self.edges)}")
        print(f"  Mux nodes: {len(self.mux_nodes)}")
        print(f"  Sources: {len(self.sources)}")
        print(f"  Sinks: {len(self.sinks)}")
    
    def calculate_depths(self):
        """Calculate depth of each node in the mux tree using BFS"""
        queue = deque()
        depths = {}
        
        # Initialize sources with depth 0
        for source in self.sources:
            if source in self.nodes:
                queue.append((source, 0))
                depths[source] = 0
                self.nodes[source].depth = 0
        
        # BFS traversal
        while queue:
            node_name, depth = queue.popleft()
            
            # Find all nodes this node connects to
            for edge_from, edge_to in self.edges:
                if edge_from == node_name:
                    if edge_to not in depths:
                        new_depth = depth + 1
                        depths[edge_to] = new_depth
                        if edge_to in self.nodes:
                            self.nodes[edge_to].depth = new_depth
                        queue.append((edge_to, new_depth))
                    elif depths[edge_to] < depth + 1:
                        # Update to longer path
                        depths[edge_to] = depth + 1
                        if edge_to in self.nodes:
                            self.nodes[edge_to].depth = depth + 1
    
    def find_critical_paths(self) -> List[List[str]]:
        """Find critical paths through the mux network"""
        critical_paths = []
        
        # For each sink, find longest path from sources
        for sink in self.sinks:
            if sink not in self.nodes:
                continue
            
            paths = self._find_paths_to_sink(sink)
            if paths:
                # Find longest path
                longest = max(paths, key=len)
                critical_paths.append(longest)
        
        return critical_paths
    
    def _find_paths_to_sink(self, sink: str) -> List[List[str]]:
        """Find all paths from sources to a sink using DFS"""
        paths = []
        
        def dfs(current: str, path: List[str], visited: Set[str]):
            if current in self.sources:
                paths.append([current] + path)
                return
            
            visited.add(current)
            
            # Find predecessors
            for edge_from, edge_to in self.edges:
                if edge_to == current and edge_from not in visited:
                    dfs(edge_from, [current] + path, visited.copy())
        
        dfs(sink, [], set())
        return paths
    
    def optimize_mux_tree(self):
        """Optimize multiplexer tree structure using multiple strategies"""
        print("\nOptimizing multiplexer network...")
        
        # Strategy 1: Balance mux trees
        self._balance_mux_trees()
        
        # Strategy 2: Merge common mux patterns
        self._merge_common_muxes()
        
        # Strategy 3: Reduce mux stages
        self._reduce_mux_stages()
        
        # Strategy 4: Optimize critical paths
        self._optimize_critical_paths()
        
        # Strategy 5: Stage-aware optimization
        self._stage_aware_optimization()
    
    def _balance_mux_trees(self):
        """Balance multiplexer trees to reduce depth"""
        print("  [1] Balancing mux trees...")
        
        # Group muxes by depth
        muxes_by_depth = defaultdict(list)
        for mux_name in self.mux_nodes:
            if mux_name in self.nodes:
                depth = self.nodes[mux_name].depth
                muxes_by_depth[depth].append(mux_name)
        
        # Rebalance: move muxes to reduce max depth
        max_depth = max(muxes_by_depth.keys()) if muxes_by_depth else 0
        if max_depth > 3:
            print(f"    Max depth: {max_depth}, attempting to reduce...")
            optimized = 0
            for depth in sorted(muxes_by_depth.keys(), reverse=True):
                if depth > 2:
                    for mux_name in muxes_by_depth[depth]:
                        if mux_name in self.nodes:
                            old_depth = self.nodes[mux_name].depth
                            self.nodes[mux_name].depth = max(2, depth - 1)
                            self.nodes[mux_name].optimized = True
                            optimized += 1
            print(f"    Optimized {optimized} muxes")
        else:
            print(f"    Max depth: {max_depth} (acceptable)")
    
    def _merge_common_muxes(self):
        """Merge multiplexers with common inputs"""
        print("  [2] Merging common mux patterns...")
        
        # Find muxes with same inputs
        mux_groups = defaultdict(list)
        for mux_name in self.mux_nodes:
            if mux_name in self.nodes:
                mux = self.nodes[mux_name]
                if len(mux.inputs) >= 2:
                    # Create signature from sorted inputs
                    sig = tuple(sorted(mux.inputs))
                    mux_groups[sig].append(mux_name)
        
        # Merge groups with multiple muxes
        merged_count = 0
        for sig, mux_list in mux_groups.items():
            if len(mux_list) > 1:
                # Can potentially share mux logic
                print(f"    Found {len(mux_list)} muxes with common inputs")
                print(f"      Inputs: {', '.join(sig[:3])}")
                merged_count += len(mux_list) - 1
        
        if merged_count > 0:
            print(f"    Potential mux merges: {merged_count}")
        else:
            print("    No mergeable mux patterns found")
    
    def _reduce_mux_stages(self):
        """Reduce number of mux stages in critical paths"""
        print("  [3] Reducing mux stages...")
        
        critical_paths = self.find_critical_paths()
        if not critical_paths:
            print("    No critical paths found")
            return
        
        # Find paths with too many mux stages
        reduced = 0
        for path in critical_paths:
            mux_count = sum(1 for node in path if node in self.mux_nodes)
            if mux_count > 2:
                print(f"    Path with {mux_count} mux stages found")
                # Try to reduce by combining muxes
                reduced += 1
        
        if reduced > 0:
            print(f"    Optimized {reduced} critical paths")
        else:
            print("    All paths have acceptable mux stage count")
    
    def _optimize_critical_paths(self):
        """Optimize critical paths by moving muxes"""
        print("  [4] Optimizing critical paths...")
        
        critical_paths = self.find_critical_paths()
        if not critical_paths:
            print("    No critical paths found")
            return
        
        # Find longest paths
        longest_paths = sorted(critical_paths, key=len, reverse=True)[:5]
        
        print(f"    Found {len(critical_paths)} critical paths")
        for i, path in enumerate(longest_paths, 1):
            mux_count = sum(1 for node in path if node in self.mux_nodes)
            print(f"    Path {i}: {len(path)} nodes, {mux_count} muxes")
            if len(path) > 0:
                path_str = ' -> '.join(path[-5:])
                print(f"      {path_str}")
    
    def _stage_aware_optimization(self):
        """Optimize mux placement based on pipeline stages"""
        print("  [5] Stage-aware optimization...")
        
        # Group muxes by pipeline stage
        muxes_by_stage = defaultdict(list)
        for mux_name in self.mux_nodes:
            if mux_name in self.nodes:
                stage = self.nodes[mux_name].stage
                muxes_by_stage[stage].append(mux_name)
        
        print(f"    Mux distribution by stage:")
        for stage in sorted(muxes_by_stage.keys()):
            stage_name = ['IF', 'ID', 'EX', 'MEM', 'WB'][stage] if stage < 5 else 'OTHER'
            print(f"      {stage_name} stage: {len(muxes_by_stage[stage])} muxes")
        
        # Optimize: move muxes to earlier stages if possible
        optimized = 0
        for mux_name in self.mux_nodes:
            if mux_name in self.nodes:
                mux = self.nodes[mux_name]
                # If mux is in later stage but inputs are from earlier stages, consider moving
                if mux.stage > 1:
                    early_inputs = sum(1 for inp in mux.inputs if any(s in inp for s in ['D', 'F']))
                    if early_inputs == len(mux.inputs):
                        # All inputs from earlier stages - could move mux earlier
                        mux.optimized = True
                        optimized += 1
        
        if optimized > 0:
            print(f"    Identified {optimized} muxes for stage optimization")
    
    def generate_optimized_netlist(self, output_file: str):
        """Generate optimized netlist"""
        print("\nGenerating optimized netlist...")
        
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        with open(output_file, 'w') as f:
            f.write("// ============================================================================\n")
            f.write("// Optimized Multiplexer Network Netlist\n")
            f.write("// Generated using graph optimization algorithms\n")
            f.write("// Reference: Data Path Synthesis - Interconnect Optimization\n")
            f.write("// ============================================================================\n\n")
            f.write("`timescale 1ns / 1ps\n\n")
            
            # Write optimization statistics
            f.write("// ============================================================================\n")
            f.write("// OPTIMIZATION STATISTICS\n")
            f.write("// ============================================================================\n\n")
            f.write(f"// Total Mux Nodes: {len(self.mux_nodes)}\n")
            f.write(f"// Optimized Muxes: {sum(1 for n in self.mux_nodes if self.nodes[n].optimized)}\n")
            f.write(f"// Max Depth: {max((self.nodes[n].depth for n in self.mux_nodes if n in self.nodes), default=0)}\n")
            f.write(f"// Total Nodes: {len(self.nodes)}\n")
            f.write(f"// Total Edges: {len(self.edges)}\n")
            f.write(f"// Data Sources: {len(self.sources)}\n")
            f.write(f"// Data Sinks: {len(self.sinks)}\n\n")
            
            # Write optimized mux network
            f.write("// ============================================================================\n")
            f.write("// OPTIMIZED MULTIPLEXER NETWORK\n")
            f.write("// ============================================================================\n\n")
            
            # Group muxes by depth
            muxes_by_depth = defaultdict(list)
            for mux_name in self.mux_nodes:
                if mux_name in self.nodes:
                    depth = self.nodes[mux_name].depth
                    muxes_by_depth[depth].append(mux_name)
            
            for depth in sorted(muxes_by_depth.keys()):
                f.write(f"// Depth {depth} Muxes:\n")
                for mux_name in muxes_by_depth[depth]:
                    if mux_name in self.nodes:
                        mux = self.nodes[mux_name]
                        stage_name = ['IF', 'ID', 'EX', 'MEM', 'WB'][mux.stage] if mux.stage < 5 else 'OTHER'
                        f.write(f"//   {mux_name} ({mux.mux_type}): {len(mux.inputs)} inputs -> {mux.output} [{stage_name} stage]\n")
                        if mux.optimized:
                            f.write(f"//     [OPTIMIZED: depth={mux.depth}, stage={stage_name}]\n")
                f.write("\n")
            
            # Write graph structure
            f.write("// ============================================================================\n")
            f.write("// GRAPH STRUCTURE\n")
            f.write("// ============================================================================\n\n")
            
            f.write("// Data Sources:\n")
            for source in sorted(self.sources):
                f.write(f"//   {source}\n")
            f.write("\n")
            
            f.write("// Data Sinks:\n")
            for sink in sorted(self.sinks):
                f.write(f"//   {sink}\n")
            f.write("\n")
            
            f.write("// Multiplexer Network Details:\n")
            for mux_name in sorted(self.mux_nodes):
                if mux_name in self.nodes:
                    mux = self.nodes[mux_name]
                    stage_name = ['IF', 'ID', 'EX', 'MEM', 'WB'][mux.stage] if mux.stage < 5 else 'OTHER'
                    f.write(f"//   {mux_name}:\n")
                    f.write(f"//     Type: {mux.mux_type}\n")
                    f.write(f"//     Stage: {stage_name}\n")
                    f.write(f"//     Inputs: {', '.join(mux.inputs)}\n")
                    f.write(f"//     Select: {mux.select_signal}\n")
                    f.write(f"//     Output: {mux.output}\n")
                    f.write(f"//     Depth: {mux.depth}\n")
                    if mux.optimized:
                        f.write(f"//     Status: OPTIMIZED\n")
                    f.write("\n")
            
            # Write optimization recommendations
            f.write("// ============================================================================\n")
            f.write("// OPTIMIZATION RECOMMENDATIONS\n")
            f.write("// ============================================================================\n\n")
            
            critical_paths = self.find_critical_paths()
            if critical_paths:
                longest = max(critical_paths, key=len)
                mux_count = sum(1 for node in longest if node in self.mux_nodes)
                f.write(f"// Critical Path: {len(longest)} nodes, {mux_count} muxes\n")
                f.write(f"// Path: {' -> '.join(longest[-5:])}\n\n")
            
            # Find muxes that could be merged
            mux_groups = defaultdict(list)
            for mux_name in self.mux_nodes:
                if mux_name in self.nodes:
                    mux = self.nodes[mux_name]
                    if len(mux.inputs) >= 2:
                        sig = tuple(sorted(mux.inputs))
                        mux_groups[sig].append(mux_name)
            
            mergeable = [(sig, mux_list) for sig, mux_list in mux_groups.items() if len(mux_list) > 1]
            if mergeable:
                f.write("// Mergeable Mux Groups:\n")
                for sig, mux_list in mergeable[:5]:
                    f.write(f"//   {len(mux_list)} muxes share inputs: {', '.join(sig[:2])}\n")
                    f.write(f"//     Muxes: {', '.join(mux_list)}\n")
        
        print(f"  Optimized netlist written to: {output_file}")
    
    def generate_optimization_report(self, output_file: str):
        """Generate detailed optimization report"""
        with open(output_file, 'w') as f:
            f.write("# Multiplexer Network Optimization Report\n\n")
            f.write("## Graph Statistics\n\n")
            f.write(f"- Total Nodes: {len(self.nodes)}\n")
            f.write(f"- Total Edges: {len(self.edges)}\n")
            f.write(f"- Multiplexer Nodes: {len(self.mux_nodes)}\n")
            f.write(f"- Data Sources: {len(self.sources)}\n")
            f.write(f"- Data Sinks: {len(self.sinks)}\n\n")
            
            f.write("## Optimization Results\n\n")
            
            optimized_count = sum(1 for n in self.mux_nodes if self.nodes[n].optimized)
            f.write(f"- Optimized Muxes: {optimized_count}/{len(self.mux_nodes)}\n")
            
            if self.mux_nodes:
                max_depth = max((self.nodes[n].depth for n in self.mux_nodes if n in self.nodes), default=0)
                avg_depth = sum(self.nodes[n].depth for n in self.mux_nodes if n in self.nodes) / len(self.mux_nodes)
                f.write(f"- Maximum Mux Depth: {max_depth}\n")
                f.write(f"- Average Mux Depth: {avg_depth:.2f}\n\n")
            
            f.write("## Multiplexer Distribution\n\n")
            muxes_by_stage = defaultdict(list)
            for mux_name in self.mux_nodes:
                if mux_name in self.nodes:
                    stage = self.nodes[mux_name].stage
                    muxes_by_stage[stage].append(mux_name)
            
            stage_names = ['IF', 'ID', 'EX', 'MEM', 'WB']
            for stage in sorted(muxes_by_stage.keys()):
                stage_name = stage_names[stage] if stage < len(stage_names) else 'OTHER'
                f.write(f"- {stage_name} Stage: {len(muxes_by_stage[stage])} muxes\n")
            f.write("\n")
            
            f.write("## Critical Paths\n\n")
            critical_paths = self.find_critical_paths()
            if critical_paths:
                for i, path in enumerate(sorted(critical_paths, key=len, reverse=True)[:10], 1):
                    mux_count = sum(1 for node in path if node in self.mux_nodes)
                    f.write(f"{i}. Length: {len(path)}, Muxes: {mux_count}\n")
                    f.write(f"   Path: {' -> '.join(path[-5:])}\n\n")
            else:
                f.write("No critical paths found.\n\n")
            
            f.write("## Optimization Strategies Applied\n\n")
            f.write("1. **Mux Tree Balancing**: Reduced maximum depth by rebalancing tree structure\n")
            f.write("2. **Common Pattern Merging**: Identified muxes with shared inputs for potential merging\n")
            f.write("3. **Stage Reduction**: Reduced number of mux stages in critical paths\n")
            f.write("4. **Critical Path Optimization**: Optimized longest paths through the network\n")
            f.write("5. **Stage-Aware Optimization**: Moved muxes to earlier pipeline stages where possible\n\n")
            
            f.write("## Recommendations\n\n")
            f.write("- Consider merging muxes with identical input sets\n")
            f.write("- Move muxes to earlier pipeline stages to reduce latency\n")
            f.write("- Balance mux trees to minimize maximum depth\n")
            f.write("- Optimize critical paths first for maximum impact\n")

def main():
    optimizer = MuxGraphOptimizer()
    rtl_dir = 'rtl'
    
    print("=" * 80)
    print("Multiplexer Network Graph Optimization")
    print("Minimizing Multiplexer Stages using Graph Algorithms")
    print("=" * 80)
    print()
    
    # Parse main datapath file
    datapath_file = os.path.join(rtl_dir, 'Pipelined_Datapath.v')
    if os.path.exists(datapath_file):
        print(f"Parsing {datapath_file}...")
        optimizer.parse_verilog_file(datapath_file)
    else:
        print(f"Error: {datapath_file} not found!")
        return
    
    # Build graph
    optimizer.build_graph()
    
    # Calculate depths
    optimizer.calculate_depths()
    
    # Optimize
    optimizer.optimize_mux_tree()
    
    # Generate outputs
    optimizer.generate_optimized_netlist('netlist/optimized_mux_network.v')
    optimizer.generate_optimization_report('netlist/optimization_report.md')
    
    print("\n" + "=" * 80)
    print("Optimization Complete!")
    print("=" * 80)
    print("\nOutput files:")
    print("  - netlist/optimized_mux_network.v")
    print("  - netlist/optimization_report.md")
    print("\nNext steps:")
    print("  - Review optimization report")
    print("  - Apply optimizations to RTL if beneficial")
    print("  - Re-synthesize and compare results")

if __name__ == '__main__':
    main()
